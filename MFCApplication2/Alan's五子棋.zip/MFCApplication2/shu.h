#pragma once
#ifndef	SHU
#define SHU

class shu
{
public:
	int	shuiping;
	int shuzhi;
	int zuoxie;
	int youxie;;

};
#endif // !POINT
#pragma once
