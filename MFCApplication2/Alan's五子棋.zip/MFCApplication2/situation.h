#pragma once
#ifndef	SITUATION
#define SITUATION

class situation
{
public:
	int five_win = 0, four_live = 0, four_chong = 0, four_die = 0, three_live = 0,
		three_sleep = 0, two_live = 0, two_sleep = 0;
	
	int score(int ,int );
};
#endif // !POINT
